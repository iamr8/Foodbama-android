package com.mikaco.foodbama.r8;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;
/**
 * Created by Arash on 1/29/2018.
 */

@GlideModule
public final class MyAppGlideModule  extends AppGlideModule {}
