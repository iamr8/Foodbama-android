package com.mikaco.foodbama.model;

import com.google.gson.annotations.SerializedName;

public class MainViewTopSliderModel {
    @SerializedName("id")
    public int id;
    @SerializedName("img")
    public String img;
}
